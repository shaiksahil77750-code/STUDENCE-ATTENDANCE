---
name: Academic Precision
colors:
  surface: '#faf8ff'
  surface-dim: '#dad9e1'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3fa'
  surface-container: '#eeedf4'
  surface-container-high: '#e9e7ef'
  surface-container-highest: '#e3e1e9'
  on-surface: '#1a1b21'
  on-surface-variant: '#444651'
  inverse-surface: '#2f3036'
  inverse-on-surface: '#f1f0f7'
  outline: '#757682'
  outline-variant: '#c5c5d3'
  surface-tint: '#4059aa'
  primary: '#00236f'
  on-primary: '#ffffff'
  primary-container: '#1e3a8a'
  on-primary-container: '#90a8ff'
  inverse-primary: '#b6c4ff'
  secondary: '#4b41e1'
  on-secondary: '#ffffff'
  secondary-container: '#645efb'
  on-secondary-container: '#fffbff'
  tertiary: '#4b1c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#6e2c00'
  on-tertiary-container: '#f39461'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dce1ff'
  primary-fixed-dim: '#b6c4ff'
  on-primary-fixed: '#00164e'
  on-primary-fixed-variant: '#264191'
  secondary-fixed: '#e2dfff'
  secondary-fixed-dim: '#c3c0ff'
  on-secondary-fixed: '#0f0069'
  on-secondary-fixed-variant: '#3323cc'
  tertiary-fixed: '#ffdbcb'
  tertiary-fixed-dim: '#ffb691'
  on-tertiary-fixed: '#341100'
  on-tertiary-fixed-variant: '#773205'
  background: '#faf8ff'
  on-background: '#1a1b21'
  surface-variant: '#e3e1e9'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  max-width: 1440px
---

## Brand & Style

The design system is built for an academic environment that demands both institutional trust and modern efficiency. The brand personality is authoritative yet accessible, positioning itself as a reliable partner for educators and administrators. 

The visual style follows a **Corporate / Modern SaaS** aesthetic with high data density and exceptional clarity. It prioritizes functional minimalism, utilizing generous white space to prevent cognitive overload during complex administrative tasks. The interface should feel "quiet" and structured, allowing the user's focus to remain entirely on the data and attendance metrics. High-fidelity details—such as micro-interactions and subtle transitions—convey the precision of the platform's tracking capabilities.

## Colors

The palette is anchored by **Academic Blue**, providing a sense of stability and institutional history. This is complemented by a more vibrant **Deep Indigo** for interactive elements and primary actions to drive user flow.

Semantic colors are critical for this design system to provide instant status recognition:
- **Success (Emerald):** Used exclusively for "Present" statuses and positive growth trends.
- **Danger (Rose):** Reserved for "Absent" statuses and critical attendance alerts.
- **Warning (Amber):** Indicates "Below Target" or "Late" statuses.

For **Dark Mode**, surfaces transition to a deep Slate-Gray (`#0F172A`) rather than pure black, maintaining soft contrast that reduces eye strain during extended grading or administrative sessions.

## Typography

The design system utilizes **Inter** as its primary typeface to ensure maximum legibility across all screen sizes. Inter's tall x-height and neutral character make it ideal for dense data tables and long lists of student names.

A secondary typeface, **JetBrains Mono**, is introduced specifically for numerical data and timestamps. This ensures that attendance percentages, IDs, and time-stamps align vertically in tables, making it easier for administrators to scan and compare values rapidly.

- **Headlines:** Use tight letter-spacing to maintain a compact, professional look.
- **Body Text:** Standardized on a 14px base for the dashboard to maximize the information visible on screen without sacrificing readability.
- **Labels:** Uppercase labels are used for category headers and table headers to create clear structural separation.

## Layout & Spacing

This design system employs a **Fluid Grid** philosophy optimized for high-density information. The system is built on a 4px baseline grid to ensure all components and spacing feel mathematically consistent.

### Desktop (1024px+)
- 12-column grid.
- 32px side margins.
- 16px gutters.
- Uses a persistent left-hand navigation sidebar (240px width).

### Tablet (768px - 1023px)
- 8-column grid.
- 24px side margins.
- 16px gutters.
- Sidebar collapses into a drawer.

### Mobile (under 768px)
- 4-column grid.
- 16px side margins.
- 12px gutters.
- Data tables should transition into list cards or use horizontal scrolling for attendance matrices.

## Elevation & Depth

To maintain a clean SaaS aesthetic, this design system avoids heavy shadows. Depth is communicated through **Tonal Layering** and subtle, ambient shadows.

- **Level 0 (Base):** The page background, using a slight off-white (`#F8FAFC`) or deep slate (`#0F172A`).
- **Level 1 (Cards/Surfaces):** Content containers use a white background with a 1px border (`#E2E8F0`) and a very soft, diffused shadow (0px 1px 3px rgba(0,0,0,0.1)).
- **Level 2 (Popovers/Dropdowns):** Use a slightly more pronounced shadow (0px 10px 15px -3px rgba(0,0,0,0.1)) to indicate they are floating above the interface.
- **Level 3 (Modals):** Centered with a dark backdrop blur (4px) to focus user attention on the primary task.

## Shapes

The shape language is "Soft-Professional." A `roundedness` level of **2** is applied throughout to strike a balance between the rigid structure of academia and the friendliness of modern software.

- **Primary Components:** Buttons, inputs, and small cards use a **8px (0.5rem)** radius.
- **Large Components:** Dashboard widgets and main containers use a **16px (1rem)** radius to anchor the page layout.
- **Status Badges:** Use a fully rounded (pill) shape to distinguish them from interactive buttons.
- **Progress Bars:** Use a 4px radius for the track and the indicator to keep them sleek.

## Components

### Buttons
- **Primary:** Solid Deep Indigo with white text. High contrast, 8px radius.
- **Secondary:** Academic Blue outline with 1px border.
- **Ghost:** No background or border, used for utility actions (e.g., "Cancel", "Clear").

### Attendance Badges
- High-contrast, small pill-shaped badges.
- **Present:** Emerald background with dark green text.
- **Absent:** Rose background with dark red text.
- **Late:** Amber background with dark brown text.

### Input Fields
- 1px border (`#CBD5E1`), 8px radius. 
- On focus: 1px Academic Blue border with a soft blue outer glow (3px).
- Labels are always visible above the field in `label-caps` style.

### Attendance Cards (Student Profile)
- Features a small 40px circular avatar.
- Displays a horizontal progress bar for "Attendance Rate" with color-coding (Red if <80%, Amber 80-90%, Green >90%).
- Includes a quick-action toggle for marking daily attendance.

### Data Tables
- Header row uses a light gray background (`#F1F5F9`) with `label-caps` text.
- Row hover state: Subtle background tint (`#F8FAFC`).
- 0px border between rows to maximize vertical space; use 1px horizontal dividers instead.

### Progress Bars
- Height: 8px.
- Background: Light gray track (`#E2E8F0`).
- Fill: Primary or Semantic color depending on the metric being displayed.